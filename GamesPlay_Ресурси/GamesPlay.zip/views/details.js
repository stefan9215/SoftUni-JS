import {html} from "../api/lib.js";
import {deleteGame, getComments, getGameById, postComment} from "../api/data.js";

const detailsTemplate = (game, isOwner, isLogged, onDelete, comments, onComment) => html`
    <section id="game-details">
        <h1>Game Details</h1>
        <div class="info-section">

            <div class="game-header">
                <img class="game-img" src=${game.imageUrl}/>
                <h1>${game.title}</h1>
                <span class="levels">${game.maxLevel}</span>
                <p class="type">${game.category}</p>
            </div>
            <p class="text">${game.summary}</p>

            ${commentsTemplate(comments)}

            ${isOwner ? html`
                        <div class="buttons">
                            <a href="/edit/${game._id}" class="button">Edit</a>
                            <a @click="${onDelete}" href="javascript:void(0)" class="button">Delete</a>
                        </div>
                    `
                    : isLogged ? addCommentTemplate(onComment) : null}
        </div>

    </section>`;

const commentsTemplate = (comments) => html`
    <div class="details-comments">
        <h2>Comments:</h2>
        <ul>
            ${comments.length > 0
                    ? comments.map(commentCard)
                    : html`<p className="no-comment">No comments.</p>`
            }
        </ul>
    </div>`;

const commentCard = (comment) => html`
    <li class="comment">
        <p>${comment.comment}</p>
    </li>`;

const addCommentTemplate = (onComment) => html`
    <article class="create-comment">
        <label>Add new comment:</label>
        <form @submit="${onComment}" class="form">
            <textarea name="comment" placeholder="Comment......"></textarea>
            <input class="btn submit" type="submit" value="Add Comment">
        </form>
    </article>`;


export async function detailsPage(ctx) {
    const gameId = ctx.params.id;
    const [game, comments] = await Promise.all([
        getGameById(gameId),
        getComments(gameId)
    ]);
    const user = JSON.parse(sessionStorage.getItem('userData'));
    const isOwner = user && user.id == game._ownerId;
    const isLogged = user;


    ctx.render(detailsTemplate(game, isOwner, isLogged, onDelete, comments, onComment));

    async function onDelete() {
        await deleteGame(gameId);
        ctx.page.redirect('/');
    }

    async function onComment(e) {
        e.preventDefault();

        const commentData = new FormData(e.target);
        const comment = commentData.get('comment');

        if (comment == '') {
            return alert('Cannot send empty comment');
        }


        // const data = {
        //     gameId: ctx.params.id,
        //     comment
        // }
        try {
            await postComment({
                gameId,
                comment
            });

        } catch (err) {
            alert(err.message)
        }
        e.target.reset();
        ctx.page.redirect('/details/' + gameId);
    }
}

/*

<!-- Bonus ( for Guests and Users ) -->


<!-- Bonus -->
<!-- Add Comment ( Only for logged-in users, which is not creators of the current game ) -->

*/